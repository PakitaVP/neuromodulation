%% Script for gPPI analysis

% In general:
% Make sure spm8 is installed
% Check the parameters.mat file in the PPI folder
% Check the following steps in this script:
% step (1): check paths
% step (2): define a name for your output folders according to region name
% step (3): define a name for your output folders according to region name
% step (4): define all region files, i.e. the masks of each seed
% step (5): define contrasts 

%%
function PPPI_FSFAST_WRAPPER()

% spm8 benutzen!! 
spmpath = which('spm')
if(~isempty(spmpath))
    rmpath(genpath(fileparts(spmpath)))
end
clear classes


bool_OS_linux = 1;

% Do step (1): check paths
if (1 == bool_OS_linux)
    subjects_description = readtable('/media/sf_Share_NeuroDebian/cofeed16/cofeed16/SubjectDescriptionGroups2.csv', 'Delimiter',',','ReadVariableNames',true);
    addpath(genpath('/usr/local/MATLAB/R2016b/toolbox/spm8'));
    addpath('/media/sf_Share_NeuroDebian/cofeed16/cofeed16/batches/NF_VTA_MVPA/spm/PPI/PPPIv13/')
    Study_Dir='/media/sf_Share_NeuroDebian/cofeed16/cofeed16/analysis/';
    Mask_Dir_indiv='/media/sf_Share_NeuroDebian/cofeed16/cofeed16/preproc/';
    Mask_Dir_MNI = '/media/sf_Share_NeuroDebian/cofeed16/cofeed16/masks/';
    Mask_Dir_Special = '/media/sf_Share_NeuroDebian/masks_general/Mask_extracts/Masks_20180917/';
    param_file = '/media/sf_Share_NeuroDebian/cofeed16/cofeed16/batches/NF_VTA_MVPA/spm/PPI/parameters.mat';

else
    subjects_description = readtable('H:\Share_NeuroDebian\cofeed16\cofeed16\SubjectDescriptionGroups2.csv', 'Delimiter',',','ReadVariableNames',true);
    addpath(genpath(''));
    addpath('H:\Share_NeuroDebian\cofeed16\cofeed16\batches\NF_VTA_MVPA\spm\PPI\PPPIv13\')
    Study_Dir='H:\Share_NeuroDebian\cofeed16\cofeed16\analysis\';
    Mask_Dir_indiv='H:\Share_NeuroDebian\cofeed16\cofeed16\preproc\';
    Mask_Dir_MNI = 'H:\Share_NeuroDebian\cofeed16\cofeed16\masks\';
    Mask_Dir_Special = 'H:\Share_NeuroDebian\masks_general\Mask_extracts\Masks_20180917\';
    param_file = 'H:\Share_NeuroDebian\cofeed16\cofeed16\batches\NF_VTA_MVPA\spm\PPI\parameters.mat';

end
Subjects = subjects_description.SubjectID(:);


regionfile={};

% Do step (2): define a name for your output folders according to region name
regionname={'VOI_SN_VTA_gPPI', 'VOI_rSN1mm_gPPI', 'VOI_SNwfu_gPPI', 'VOI_probSNVTA_gPPI', 'VOI_dlPFC_NF_gPPI'};

models={'.rh'};

% Check that all subjects are in
for indSubj=1:1%size(Subjects,1)
    try
        clear config
    catch
    end
    
       
    config.Subject=Subjects{indSubj};
    config.Study=Study_Dir;
    config.Subject_Subdirectory='stats_mni_allruns_newreg';
    config.zip=0;
    
    % individual masks - have to fit regionname vector
    subjects_mask_file_name = fullfile(Mask_Dir_indiv,...
        Subjects{indSubj},'ROI','w_lh_newreg_thr_SN_VTA_ROI_LH.nii');
    % Do step (3): define all region files, i.e. the masks of each seed
    regionfile={subjects_mask_file_name, fullfile(Mask_Dir_MNI, 'rSN_1mm.nii'), fullfile(Mask_Dir_MNI, 'rSNwfu.nii'), fullfile(Mask_Dir_MNI, 'rmask_probSNVTA.nii'), fullfile(Mask_Dir_Special, 'ROI_NF_dlPFC.nii')};
    
    % % Check which seed regions to use
    for jj=5:numel(regionfile)
        try
            Directory=fullfile(config.Study, Subjects{indSubj}, config.Subject_Subdirectory);
            cd(Directory)
            load(param_file);
            P.subject=Subjects{indSubj};
            P.directory=Directory;
            
            
            P.VOI=regionfile{jj};
            P.Region=regionname{jj};
            %P.FSFAST=1;
            %P.FSFAST_source=[Study_Dir filesep Subjects{ii} filesep config.Subject_Subdirectory filesep 'SPMana' filesep config.Model models{3} filesep 'SPM.mat']; % subcortical iamge for ROI extraction
            P.wb=0; % may need to be changed to 0 on local computers
            P.concatR=0;
            % Do step (5): define contrasts 
            P.Contrasts(1).left={'UP'}; 
            P.Contrasts(1).right={'none'}; 
            P.Contrasts(1).STAT='T'; 
            P.Contrasts(1).Weighted=0; 
            P.Contrasts(1).MinEvents=1; 
            P.Contrasts(1).name='UP_r1'; 
            
            P.Contrasts(2).left={'UP'}; 
            P.Contrasts(2).right={'none'}; 
            P.Contrasts(2).STAT='T'; 
            P.Contrasts(2).Weighted=0; 
            P.Contrasts(2).MinEvents=1; 
            P.Contrasts(2).name='UP_r2'; 
            
            P.Contrasts(3).left={'UP'}; 
            P.Contrasts(3).right={'none'}; 
            P.Contrasts(3).STAT='T'; 
            P.Contrasts(3).Weighted=0; 
            P.Contrasts(3).MinEvents=1; 
            P.Contrasts(3).name='UP_r3';
            
            P.Contrasts(4).left={'UP'}; 
            P.Contrasts(4).right={'none'}; 
            P.Contrasts(4).STAT='T'; 
            P.Contrasts(4).Weighted=0; 
            P.Contrasts(4).MinEvents=1; 
            P.Contrasts(4).name='UP_r4';
            
            P.Contrasts(5).left={'DOWN'}; 
            P.Contrasts(5).right={'none'}; 
            P.Contrasts(5).STAT='T'; 
            P.Contrasts(5).Weighted=0; 
            P.Contrasts(5).MinEvents=1; 
            P.Contrasts(5).name='DOWN_r1';
            
            P.Contrasts(6).left={'DOWN'}; 
            P.Contrasts(6).right={'none'}; 
            P.Contrasts(6).STAT='T'; 
            P.Contrasts(6).Weighted=0; 
            P.Contrasts(6).MinEvents=1; 
            P.Contrasts(6).name='DOWN_r2';
            
            P.Contrasts(7).left={'DOWN'}; 
            P.Contrasts(7).right={'none'}; 
            P.Contrasts(7).STAT='T'; 
            P.Contrasts(7).Weighted=0; 
            P.Contrasts(7).MinEvents=1; 
            P.Contrasts(7).name='DOWN_r3';

            P.Contrasts(8).left={'DOWN'}; 
            P.Contrasts(8).right={'none'}; 
            P.Contrasts(8).STAT='T'; 
            P.Contrasts(8).Weighted=0; 
            P.Contrasts(8).MinEvents=1; 
            P.Contrasts(8).name='DOWN_r4';
            
            P.Contrasts(9).left={'UP'}; 
            P.Contrasts(9).right={'DOWN'}; 
            P.Contrasts(9).STAT='T'; 
            P.Contrasts(9).Weighted=0; 
            P.Contrasts(9).MinEvents=1; 
            P.Contrasts(9).name='UP-DOWN_r1';
            
            P.Contrasts(10).left={'UP'}; 
            P.Contrasts(10).right={'DOWN'}; 
            P.Contrasts(10).STAT='T'; 
            P.Contrasts(10).Weighted=0; 
            P.Contrasts(10).MinEvents=1; 
            P.Contrasts(10).name='UP-DOWN_r2';
            
            P.Contrasts(11).left={'UP'}; 
            P.Contrasts(11).right={'DOWN'}; 
            P.Contrasts(11).STAT='T'; 
            P.Contrasts(11).Weighted=0; 
            P.Contrasts(11).MinEvents=1; 
            P.Contrasts(11).name='UP-DOWN_r3';
            
            P.Contrasts(12).left={'UP'}; 
            P.Contrasts(12).right={'DOWN'}; 
            P.Contrasts(12).STAT='T'; 
            P.Contrasts(12).Weighted=0; 
            P.Contrasts(12).MinEvents=1; 
            P.Contrasts(12).name='UP-DOWN_r4';

            % all this crap is not working, I only can create basic
            % contrasts 
%             P.Contrasts(13).left={'UP','UP','UP','UP'}; 
%             P.Contrasts(13).right={'DOWN','DOWN','DOWN','DOWN'}; 
%             P.Contrasts(13).STAT='T'; 
%             P.Contrasts(13).Weighted=0; 
%             P.Contrasts(13).MinEvents=1; 
%             P.Contrasts(13).name='UP-DOWN_allruns';
%             P.Contrasts(13).Prefix={'Sn(1), Sn(2), Sn(3), Sn(4)'};
%             
%                         
%             P.Contrasts(14).left={'UP','UP'}; 
%             P.Contrasts(14).right={'DOWN','DOWN'}; 
%             P.Contrasts(14).STAT='T'; 
%             P.Contrasts(14).Weighted=0; 
%             P.Contrasts(14).MinEvents=1; 
%             P.Contrasts(14).name='UP-DOWN_r4-r1';
%             P.Contrasts(14).Prefix={'Sn(4), Sn(1)'};
            
            save([Subjects{indSubj} '_PPI_config.mat'],'P');
            PPPI([Subjects{indSubj} '_PPI_config.mat'])
        catch
            disp(['Failed: ' Subjects{indSubj}])
        end
        %end
    end
    % You will want to zip the files here if P.zipfiles is not set to 1.
end

